package com.example;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

public class PrimaryController {

    @FXML
    private HBox mesaDoJogador;
    @FXML
    private HBox mesaDoComputador;
    @FXML
    private ImageView monte;

    @FXML
    private Label pontosMesa;
    @FXML
    private Label pontosJogador;
    @FXML
    private Label resultado;

    private Jogo jogo = new Jogo();

    public void turno() {
        if (!jogo.jogador.parou && jogo.jogador.getPontos() < 21) {

            Carta cartaJogador = jogo.distribuirCartaParaJogador(jogo.jogador);
            jogo.jogador.cartas.add(cartaJogador);
            jogo.jogador.setPontos(cartaJogador.getNumero());
    

            if (jogo.jogador.getPontos() >= 21) {
                jogo.jogador.parar();
                
                Carta cartaComputador = jogo.distribuirCartaParaJogador(jogo.computador);
                jogo.computador.cartas.add(cartaComputador);
                jogo.computador.setPontos(cartaComputador.getNumero());
                jogo.computador.parar();
            }
        } else {

            if (!jogo.computador.parou) {
                if (jogo.computador.getPontos() >= 16 && (jogo.computador.getPontos() > jogo.jogador.getPontos())) {
                    jogo.computador.parar();
                } else {

                    Carta cartaComputador = jogo.distribuirCartaParaJogador(jogo.computador);
                    jogo.computador.cartas.add(cartaComputador);
                    jogo.computador.setPontos(cartaComputador.getNumero());
                }
            }
        }
        atualizar();
    }

    public void atualizar() {
        pontosJogador.setText("Jogador: " + jogo.jogador.getPontos());
        pontosMesa.setText("Mesa: " + jogo.computador.getPontos());

        mesaDoJogador.getChildren().clear();
        mesaDoComputador.getChildren().clear();

        jogo.jogador.getCartas().forEach((carta) -> mesaDoJogador.getChildren().add(imagemCarta(carta)));
        jogo.computador.getCartas().forEach((carta) -> mesaDoComputador.getChildren().add(imagemCarta(carta)));
    }

    public void novoJogo() {
        jogo = new Jogo();
        jogo.monte.embaralhar();
        mesaDoJogador.getChildren().clear();
        mesaDoComputador.getChildren().clear();
        pontosJogador.setText("Jogador: 0");
        pontosMesa.setText("Mesa: 0");
        resultado.setText("");
    }

    public void pedirCarta() {
        turno();
    }

    public void parar() {
        jogo.jogador.parar();
        turno();
    }

    private ImageView imagemCarta(Carta carta) {
        return new ImageView(App.class.getResource(carta.imagePath()).toString());
    }

}
