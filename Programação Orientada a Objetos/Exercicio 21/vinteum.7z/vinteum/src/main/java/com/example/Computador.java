package com.example;

public class Computador extends Jogador{


}
