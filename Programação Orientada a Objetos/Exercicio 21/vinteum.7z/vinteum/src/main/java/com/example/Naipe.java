package com.example;

public enum Naipe {
    Hearts,
    Spades,
    Diamonds,
    Clubs
}
