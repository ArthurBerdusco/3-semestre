package com.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Monte {

    List<Carta> cartas = new ArrayList<>();

    public Monte() {
        // Adicione as 52 cartas ao monte
        for (Naipe naipe : Naipe.values()) {
            for (int numero = 1; numero <= 13; numero++) {
                Carta carta = new Carta(numero, naipe);
                cartas.add(carta);
            }
        }
    }

    public void embaralhar() {
        Collections.shuffle(cartas); 
    }

    public Carta virar() {
        if (!cartas.isEmpty()) {
            return cartas.remove(0); 
        }
        return null; 
    }

}
