package com.example;

import java.util.ArrayList;
import java.util.List;

public class Jogador {
    int pontos = 0;
    List<Carta> cartas = new ArrayList<>();
    boolean parou = false;

    public void receberCarta(Carta carta){
        cartas.add(carta);
    }

    public int getPontos() {
        return pontos;
    }

    public List<Carta> getCartas() {
        return cartas;
    }

    public boolean parou() {
        return parou;
    }
    
}
