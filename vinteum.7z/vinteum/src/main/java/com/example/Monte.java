package com.example;

import java.util.ArrayList;
import java.util.List;

public class Monte {

    List<Carta> cartas = new ArrayList<>();

    public Monte() {
    }

    public void embaralhar(){
        cartas.shuflle;
    }

    public Carta virar() {
        cartas.get(RANDOM);
    }

    

}
