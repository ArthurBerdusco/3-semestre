package com.example;

public class Computador extends Jogador{

    public boolean parou(){
        boolean parou = false;
        return parou;
    }

}
