package com.example;

import java.util.Random;

public class Jogo {

    Monte monte = new Monte();
    Jogador jogador = new Jogador();
    Computador computador = new Computador();

    public Jogo() {
    }

    public Carta distribuirCartaParaJogador(Jogador jogador) {
        return new Carta(new Random().nextInt(), Naipe.Hearts);
    }

    public boolean acabou() {
        return false;
    }

    public String resultado() {
        return "";
    }

    public Computador getComputador() {
        return new Computador();
    }

    public Jogador getJogador() {
        return new Jogador();
    }

}
